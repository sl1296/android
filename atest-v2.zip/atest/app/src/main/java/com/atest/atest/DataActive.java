package com.atest.atest;

public class DataActive {
    String title, item;
    DataActive(String vtitle, String vitem) {
        title = vtitle;
        item = vitem;
    }
}
