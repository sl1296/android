package com.atest.atest;

import android.widget.TextView;

public class ViewHolderTextWeb {
    TextView title, item;
}
