package com.atest.atest;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolderFreeTimeFocus {
    TextView title, item;
    ImageView image;
}
