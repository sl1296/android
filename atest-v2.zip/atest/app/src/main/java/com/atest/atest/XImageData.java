package com.atest.atest;

public class XImageData {
    int photo;
    public  XImageData(int p)
    {
        photo=p;
    }
}
