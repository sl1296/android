package com.atest.atest;

import android.widget.TextView;

public class ViewHolderFreeTimeActive {
    TextView title, item;
}
